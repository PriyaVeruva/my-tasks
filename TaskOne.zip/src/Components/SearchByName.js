import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";

import {
  Grid,
  Card,
  Typography,
  CardContent,
  CardHeader,
  Container,
} from "@mui/material";

import { Link, withRouter, Route } from "react-router-dom";
const SearchByName = (props) => {
  const [country, setCountry] = useState({});
  const dispatch = useDispatch();

  const countries = useSelector((state) => {
    return state.countries;
  });
  useEffect(() => {
    if (countries.length > 0) {
      const result = countries.find(
        (ele) => ele.name === props.match.params.id
      );
      setCountry(result);
    }
  }, [countries]);
  return (
    <div>
      <Container>
        <Grid container spacing={1}>
          <Grid item xs={10} md={6} lg={4}>
            <Link
              to="/"
              style={{ textDecoration: "none", textAlign: "revert" }}
            >
              <ArrowBackIcon style={{ paddingTop: "30px" }} />
              Back
            </Link>

            {Object.keys(country).length > 0 && (
              <div style={{ display: "flex" }}>
                <div>
                  <img
                    src={country.flags && country.flags.png}
                    style={{ display: "flex", marginTop: 30 }}
                  />
                </div>

                <div
                  style={{
                    paddingTop: "30px",
                    paddingLeft: "30px",
                    display: "flex",
                  }}
                >
                  <div>
                    <h3>{country.name}</h3>
                    <br />
                    <p>NativeName:{country.nativeName}</p>
                    <br />
                    <p>Population:{country.population}</p>
                    <br />

                    <p>Region:{country.region}</p>
                    <br />
                    <p>SubRegion:{country.subregion}</p>
                    <br />
                    <p>Capital:{country.capital}</p>
                    <br />
                  </div>
                  <div style={{ paddingLeft: "60px", paddingTop: "30px" }}>
                    <p>TopLevelDomain:{country.topLevelDomain}</p>
                    <br />
                    <p>
                      Currencies:{country.currencies.map((ele) => ele.name)}
                    </p>
                    <br />
                    <p>
                      Languages:{country.languages.map((ele) => ele.name + ",")}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </Grid>
        </Grid>
      </Container>
    </div>
  );
};
export default withRouter(SearchByName);
