import React, { useState } from "react";
import { Grid, Container } from "@mui/material";
const DropDown = (props) => {
  const handleDropDownChange = (e) => {
    props.handleDropDownChange(e);
  };

  return (
    <div>
      <Container>
        <Grid container spacing={1}>
          <Grid item xs={10} md={6} lg={5}>
            <div
              style={{
                marginLeft: "64rem",
                position: "absolute",
                paddingTop: "30px",
              }}
            >
              <select
                value={props.dropDown}
                name="dropDown"
                onChange={handleDropDownChange}
              >
                <option>Filter By Region</option>
                {props?.uniqueData?.map((ele, i) => {
                  return (
                    <option key={i} value={ele}>
                      {ele}
                    </option>
                  );
                })}
              </select>
            </div>
          </Grid>
        </Grid>
      </Container>
    </div>
  );
};
export default DropDown;
